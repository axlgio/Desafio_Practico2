package com.example.desafio_practico.salario

interface Icontrolador {
    fun saldoNeto(saldo: Double?, nombre: String?)
}