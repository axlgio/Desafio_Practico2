package com.example.desafio_practico.Promedio

interface Iview {
    fun resultado(resultado: String?)
}