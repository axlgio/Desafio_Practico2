package com.example.desafio_practico.Promedio

interface Icontrolador {
    fun promedio( n1: Double?,n2: Double?,n3: Double?,n4: Double?, n5: Double?,studiante: String?)
}