package com.example.desafio_practico.calculadora

interface Iview {
    fun resultado(resultado: String?)
}