package com.example.desafio_practico.salario

interface Iview {
    fun resultado(resultado: String?)
}