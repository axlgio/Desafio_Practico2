package com.example.desafio_practico.calculadora

interface Icontrolador {
    fun calculadora(a: Double?, b: Double?, aOperar: String?)
}